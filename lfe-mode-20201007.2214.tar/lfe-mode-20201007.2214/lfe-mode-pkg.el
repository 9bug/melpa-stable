(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "5677410abffa1d1bc66b867be8918f1423fd586b")
;; Local Variables:
;; no-byte-compile: t
;; End:
