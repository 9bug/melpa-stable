(define-package "ob-crystal" "20180126.718" "org-babel functions for Crystal evaluation"
  '((emacs "24.3"))
  :commit "d84c1adee4b269cdba06a97caedb8071561a09af" :authors
  '(("Brantou" . "brantou89@gmail.com"))
  :maintainer
  '("Brantou" . "brantou89@gmail.com")
  :keywords
  '("crystal" "literate programming" "reproducible research")
  :url "https://github.com/brantou/ob-crystal")
;; Local Variables:
;; no-byte-compile: t
;; End:
