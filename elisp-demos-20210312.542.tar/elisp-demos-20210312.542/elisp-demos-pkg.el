(define-package "elisp-demos" "20210312.542" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "924b07d28e4f5b82f0e1377bcde800068f0a6d9d" :authors
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :keywords
  '("lisp" "docs")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
