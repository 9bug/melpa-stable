;;; eclim-java.el --- an interface to the Eclipse IDE.  -*- lexical-binding: t -*-
;;
;; Copyright (C) 2009  Yves Senn <yves senn * gmx ch>
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.
;;
;;; Contributors
;;
;; - Tassilo Horn <tassilo@member.fsf.org>
;;
;;; Commentary:
;;
;;; Conventions
;;
;; Conventions used in this file: Name internal variables and functions
;; "eclim--<descriptive-name>", and name eclim command invocations
;; "eclim/command-name", like eclim/project-list.
;;
;;; Code:
(require 'json)
(require 'format-spec)
(require 'eclim-common)
(require 'eclim-problems)
(eval-when-compile
  (require 'eclim-macros)
  (require 'cl-lib)
  (require 'dash))

(eclim-bind-keys (:map eclim-command-map)
  ("d"   . eclim-java-doc-comment)
  ("f d" . eclim-java-find-declaration)
  ("f f" . eclim-java-find-generic)
  ("f r" . eclim-java-find-references)
  ("f s" . eclim-java-format)
  ("f t" . eclim-java-find-type)
  ("g"   . eclim-java-generate-getter-and-setter)
  ("h"   . eclim-java-hierarchy)
  ("i"   . eclim-java-import-organize)
  ("n"   . eclim-java-new)
  ("r"   . eclim-java-refactor-rename-symbol-at-point)
  ;; this is not defined
  ;; ("s"   . eclim-java-method-signature-at-point)
  ("t"   . eclim-run-junit)
  ("z"   . eclim-java-implement))

(defvar eclim-java-show-documentation-map
  (let ((map (make-keymap)))
    (suppress-keymap map)
    (define-key map (kbd "<tab>") 'forward-button)
    (define-key map (kbd "S-<tab>") 'backward-button)
    (define-key map (kbd "q") 'eclim-quit-window)
    map))

(defgroup eclim-java nil
  "Java: editing, browsing, refactoring"
  :group 'eclim)

(defcustom eclim-java-major-modes '(java-mode jde-mode)
  "This variable contains a list of major modes to edit java files.
There are certain operations, that eclim will only perform when
the current buffer is contained within this list."
  :group 'eclim-java
  :type 'list)

;; Could this value be taken from Eclipse somehow?"
(defcustom eclim-java-documentation-root nil
  "Root directory of Java HTML documentation.

If Android is used then Eclipse may refer standard Java elements from the copy
of Java documentation under Android docs, so don't forget to set
`eclim-java-android-documentation-root' too in that case."
  :group 'eclim-java
  :type 'directory)

;; Could this value be taken from Eclipse somehow?"
(defcustom eclim-java-android-documentation-root nil
  "Root directory of Android HTML documentation."
  :group 'eclim-java
  :type 'directory)

(defvar eclim--java-new-types '("class" "interface" "abstract" "enum" "@interface"))

(defvar eclim--java-search-types '("all"
                                   "annotation"
                                   "class"
                                   "classOrEnum"
                                   "classOrInterface"
                                   "constructor"
                                   "enum"
                                   "field"
                                   "interface"
                                   "method"
                                   "package"
                                   "type"))

(defvar eclim--java-search-scopes '("all"
                                    "project"
                                    "type"))

(defvar eclim--java-search-contexts '("all"
                                      "declarations"
                                      "implementors"
                                      "references"))

(defvar eclim-java-show-documentation-history nil)
(defvar eclim--run-class-history nil)
(defvar-local eclim--run-class-commands nil
  "Alist of previously ran commands in current buffer.
See `eclim-run-class'.")

(defun eclim/groovy-src-update (&optional save-others)
  "If `eclim-auto-save' is non-nil, save the current java buffer.
In addition, if `SAVE-OTHERS' is non-nil, also save any
other unsaved buffer.  Finally, tell eclim to update its java
 sources."
  (when eclim-auto-save
    ;; auto-save current buffer, prompt on saving others
    (when (buffer-modified-p) (save-buffer))
    (when save-others
      (save-some-buffers
       nil (lambda () (string-match "\\.groovy$" (buffer-file-name)))))))

(defun eclim/java-src-update (&optional save-others)
  "If `eclim-auto-save' is non-nil, save the current java buffer.
In addition, if SAVE-OTHERS is non-nil, also save any other unsaved buffer.
 Finally, tell eclim to update its java sources."
  (when eclim-auto-save
    ;; auto-save current buffer, prompt on saving others
    (when (buffer-modified-p) (save-buffer))
    (when save-others
      (save-some-buffers
       nil (lambda () (string-match "\\.java$" (buffer-file-name)))))))

;; This is used to advise the `delete-file' (ORIG-FUNCTION) function to trigger
;; a source update in eclim when appropriate. This advice is added when
;; eclim-mode is started and removed on exit.
(defun eclim-java-delete-file (orig-function filename &optional trash)
  (let ((pr nil)
        (fn nil))
    (ignore-errors
      (and (setq pr (eclim-project-name filename))
           (setq fn (file-relative-name filename (eclim--project-dir pr)))))
    (funcall orig-function filename trash)
    (when (and pr fn)
      (ignore-errors (apply 'eclim--call-process
                            (list "java_src_update" "-p" pr "-f" fn))))))

(defun eclim--java-parser-read (str)
  (cl-first
   (read-from-string
    (format "(%s)"
            (replace-regexp-in-string
             "[<>(),?]"
             (lambda (m) (assoc-default m '(("<" . "((") (">" . "))")
                                       ("(" . "((") (")" ."))")
                                       ("," . ")(")
                                       ("?" . "\\\\?"))))
             str)))))

(defun eclim--java-parse-method-signature (signature)
  (cl-flet ((parser3/parse-arg (arg)
              (let ((arg-rev (reverse arg)))
                (cond ((null arg) nil)
                      ((= (length arg) 1) (list (list :type (cl-first arg))))
                      ((listp (cl-first arg-rev)) (list (cons :type arg)))
                      (t (list (cons :name (cl-first arg-rev))
                               (cons :type (reverse (cl-rest arg-rev)))))))))
    (let ((ast (reverse (eclim--java-parser-read signature))))
      (list (cons :arglist (mapcar #'parser3/parse-arg (cl-first ast)))
            (cons :name (cl-second ast))
            (cons :return (reverse (cl-rest (cl-rest ast))))))))

(defun eclim--java-current-type-name (&optional type)
  "Search backward in the current buffer until a type declaration has been \
found.  TYPE may be either 'class', 'interface', 'enum' or nil, meaning 'match
all of the above'."
  (save-excursion
    (if (re-search-backward
         (concat (or type "\\(class\\|interface\\|enum\\)") "\\s-+\\([^<{\s-]+\\)")
         nil 'move)
        (match-string-no-properties 2)
      "")))

(defun eclim--java-current-class-name ()
  "Search backwards in the current buffer until a class declaration has been \
found."
  (eclim--java-current-type-name "\\(class\\)"))

(defun eclim--java-generate-bean-properties (project file offset encoding type)
  "Generate a bean property for the symbol at point.
TYPE specifies the property to generate in PROJECT's FILE at OFFSET with
ENCODING."
  (eclim--call-process "java_bean_properties"
                       "-p" project
                       "-f" file
                       "-o" (number-to-string offset)
                       "-e" encoding
                       "-r" (cdr (eclim--java-identifier-at-point t))
                       "-t" type)
  (revert-buffer t t t))

(defun eclim--java-refactor (result)
  "Processes the resulst of a refactor command.
RESULT is the results of invoking eclim/execute-command."
  (if (stringp result) (error "%s" result))
  (cl-loop for (from to) in (mapcar
                             (lambda (x)
                               (list (assoc-default 'from x) (assoc-default 'to x)))
                             result)
     do (when (and from to)
          (kill-buffer (find-buffer-visiting from))
          (find-file to)))
  (save-excursion
    (cl-loop for file in (mapcar (lambda (x) (assoc-default 'file x)) result)
       do (when file
            (let ((buf (get-file-buffer (file-name-nondirectory file))))
              (when buf
                (switch-to-buffer buf)
                (revert-buffer t t t))))))
  (message "Done"))

(defun eclim/java-classpath (project)
  (eclim--check-project project)
  (eclim--call-process "java_classpath" "-p" project))

(defun eclim/java-classpath-variables ()
  ;; TODO: fix trailing whitespaces
  (mapcar (lambda (line)
            (split-string line "-"))
          (eclim--call-process "java_classpath_variables")))

(defun eclim/java-classpath-variable-create (name path)
  (eclim--call-process "java_classpath_variable_create" "-n" name "-p" path))

(defun eclim/java-classpath-variable-delete (name)
  (eclim--call-process "java_classpath_variable_create" "-n" name))

(defun eclim-java-doc-comment ()
  "Insert or update a javadoc comment for the element at point."
  (interactive)
  (eclim/execute-command "javadoc_comment" "-p" "-f" "-o"))

(defun eclim-run-java-doc ()
  "Run Javadoc on current or all projects."
  (interactive)
  (let ((proj-list (eclim/project-list)))
    (if (y-or-n-p "Run Javadoc for all projects? ")
        (dotimes (i (length proj-list))
          (eclim--call-process-no-parse "javadoc" "-p"
                                        (cl-rest (assq 'name (elt proj-list i)))))
      (eclim--call-process-no-parse "javadoc" "-p"))
    (message "Javadoc creation finished.")))

(defun eclim-java-format ()
  "Format the source code of the current java source file."
  (interactive)
  (eclim/execute-command
   "java_format" "-p" "-f" ("-h" 0) ("-t" (1- (point-max))) "-e"))

(defun eclim-java-generate-getter-and-setter (project file offset encoding)
  "Generate getter and setter methods for the symbol at point when called \
interactively.
Methods are generated in the PROJECT's FILE at OFFSET with ENCODING."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--byte-offset)
                     (eclim--current-encoding)))
  (eclim--java-generate-bean-properties project file offset encoding "gettersetter"))

(defun eclim-java-generate-getter (project file offset encoding)
  "Generate a getter method for the symbol at point.
Methods are generated in the PROJECT's FILE at OFFSET with ENCODING."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--byte-offset)
                     (eclim--current-encoding)))
  (eclim--java-generate-bean-properties project file offset encoding "getter"))

(defun eclim-java-generate-setter (project file offset encoding)
  "Generate a setter method for the symbol at point.
Methods are generated in the PROJECT's FILE at OFFSET with ENCODING."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--byte-offset)
                     (eclim--current-encoding)))
  (eclim--java-generate-bean-properties project file offset encoding "setter"))

(defun eclim-java-constructor ()
  "Generate a constructor from the selected fields."
  (interactive)
  (let ((fields (eclim--java-get-selected-fields)))
    (eclim/execute-command "java_constructor" "-p" "-f" "-o"
                           (when fields (list "-r" (json-encode fields))))))

(defun eclim--java-get-selected-fields ()
  "Return the names of the fields in the current selection."
  (when (use-region-p)
    (let ((region (eclim--current-region-no-properties)))
      ;; Remove all block comments.
      ;; TODO This doesn't account for finding an unclosed "/*" inside a string.
      (setf region (replace-regexp-in-string "/\\*\\(?:.\\|\n\\)*?\\*/" "" region))
      ;; Remove all single line comments,
      (setf region (replace-regexp-in-string "//.*" "" region))
      ;; Remove all double quoted strings, accounting for escaped quotes.
      (setf region (replace-regexp-in-string "\"\\(?:[^\"\\\\]\\|\\\\.\\)*?\"" ""
                                             region))
      ;; Remove all single quoted characters, accounting for escaped quotes.
      (setf region (replace-regexp-in-string "'\\(?:[^'\\\\]\\|\\\\.\\)*?'" ""
                                             region))
      ;; Now that string and char literals are gone, we can freely match special
      ;; characters.
      ;; Split fields onto their own lines, ensuring each is ended with a semicolon.
      (setf region (replace-regexp-in-string "\\(?:,\\|;\\)[^\n]?" ";\n" region))
      ;; Remove trailing whitespace.
      (setf region (replace-regexp-in-string "\\s-*$" "" region))
      ;; Remove the assignment portions, any whitespace between the field and
      ;; the semicolon, and any whitespace after the semicolon.
      (setf region (replace-regexp-in-string "\\s-*\\(?:=[^;]*\\)?;\\s-*$" ";"
                                             region))
      ;; Remove any line which does not end with a semicolon, since it is not a
      ;; (complete) field declaration.
      (setf region (replace-regexp-in-string "^[^\n]*[^;\n]$" "" region))
      ;; Each line is now an identifier (field name) followed by a semicolon,
      ;; with possible whitespace. Extract the field name.
      (setf region (replace-regexp-in-string "^.*?\\(\\S-*\\)\\s-*;$" "\\1" region))
      ;; Split into lines, trimming whitespace and removing empty lines. This
      ;; leaves only the field names.
      (split-string region "\n" t "\\s-*"))))

(defun eclim/java-call-hierarchy (project file offset length encoding)
  (eclim--call-process "java_callhierarchy"
                       "-p" project
                       "-f" file
                       "-o" (number-to-string offset)
                       "-l" (number-to-string length)
                       "-e" encoding))

(defun eclim/java-hierarchy (project file offset encoding)
  (eclim--call-process "java_hierarchy"
                       "-p" project
                       "-f" file
                       "-o" (number-to-string offset)
                       "-e" encoding))

(defun eclim/java-src-dirs (project)
  "Queries Eclimd for the list of source directories in the PROJECT."
  (split-string (eclim--call-process "java_src_dirs" "-p" project) "\n"))

(defun eclim-java-refactor-rename-symbol-at-point ()
  "Rename the java symbol at point."
  (interactive)
  (let* ((i (eclim--java-identifier-at-point t))
         (n (read-string (concat "Rename " (cdr i) " to: ") (cdr i))))
    (eclim/with-results res ("java_refactor_rename" "-p" "-e" "-f" ("-n" n)
                             ("-o" (car i)) ("-l" (length (cdr i))))
      (eclim--java-refactor res))))

(defun eclim-java-refactor-move-class ()
  "Renames the java class.
Searches backward in the current buffer until a
class declaration has been found."
  (interactive)
  (let* ((class-name (eclim--java-current-class-name))
         (package-name (eclim--java-current-package))
         (n (read-string (concat "Move " class-name " to: ") package-name)))
    (eclim/with-results res ("java_refactor_move" "-p" "-f" ("-n" n))
      (eclim--java-refactor res))))

(defun eclim-java-call-hierarchy (project file encoding)
  "Displays the call hierarchy for FILE in PROJECT with ENCODING."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--current-encoding)))
  (let ((boundary "\\([<>()\\[\\.\s\t\n!=,;]\\|]\\)"))
    (save-excursion
      (if (re-search-backward boundary nil t)
          (forward-char))
      (let ((top-node (eclim/java-call-hierarchy
                       project file (eclim--byte-offset)
                       (length (cdr (eclim--java-identifier-at-point t))) encoding)))
        (pop-to-buffer "*eclim: call hierarchy*" t)
        (special-mode)
        (let ((buffer-read-only nil))
          (erase-buffer)
          (eclim--java-insert-call-hierarchy-node
           project
           top-node
           0))))))

(defun eclim--java-insert-call-hierarchy-node (project node level)
  (let ((declaration (cdr (assoc 'name node))))
    (insert (format (concat "%-"(number-to-string (* level 2)) "s=> ") ""))
    (let ((position (cdr (assoc 'position node))))
      (if position
          (insert-text-button declaration
                              'follow-link t
                              'help-echo declaration
                              'action #'(lambda (&rest _)
                                          (eclim--visit-declaration position)))
        (insert declaration)))
    (newline)
    (cl-loop for caller across (cdr (assoc 'callers node))
       do (eclim--java-insert-call-hierarchy-node project caller (1+ level)))))

(defun eclim-java-hierarchy (project file offset encoding)
  "Displays the call hierarchy for the element at OFFSET in FILE in PROJECT \
with ENCODING."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--byte-offset)
                     (eclim--current-encoding)))
  (let ((top-node (eclim/java-hierarchy project file offset encoding)))
    (pop-to-buffer "*eclim: hierarchy*" t)
    (special-mode)
    (let ((buffer-read-only nil))
      (erase-buffer)
      (eclim--java-insert-hierarchy-node
       project
       top-node
       0))))

(defun eclim--java-insert-file-path-for-hierarchy-node (node)
  (eclim/with-results hits
    ("java_search" ("-p" (cdr (assoc 'qualified node)))
     ("-t" "type") ("-x" "declarations") ("-s" "workspace"))
    (assoc-default 'filename (elt hits 0))))

(defun eclim--java-insert-hierarchy-node (project node level)
  (let ((declaration (cdr (assoc 'name node)))
        (qualified-name (cdr (assoc 'qualified node))))
    (insert (format (concat "%-"(number-to-string (* level 2)) "s=> ") ""))
    (let ((file-path (eclim--java-insert-file-path-for-hierarchy-node node)))
      (if file-path
          (insert-text-button declaration
                              'follow-link t
                              'help-echo qualified-name
                              'action (lambda (&rest _)
                                        (eclim--find-file file-path)))
        (insert declaration))))
  (newline)
  (let ((children (cdr (assoc 'children node))))
    (cl-loop for child across children do
         (eclim--java-insert-hierarchy-node project child (+ level 1)))))

(defun eclim-java-find-declaration ()
  "Find and display the declaration of the java identifier at point."
  (interactive)
  (let ((i (eclim--java-identifier-at-point t)))
    (eclim/with-results hits
      ("java_search" "-n" "-f" ("-o" (car i))
       ("-l" (length (cdr i))) ("-x" "declaration"))
      (eclim--find-display-results (cdr i) hits t))))

(defun eclim-c-find-declaration ()
  "Find and display the declaration of the c identifier at point."
  (interactive)
  (let ((i (eclim--java-identifier-at-point t)))
    (eclim/with-results hits ("c_search" "-n" "-f" ("-o" (car i))
                              ("-l" (length (cdr i))))
      (eclim--find-display-results (cdr i) hits t))))

(defun eclim-java-find-references ()
  "Find and display references for the java identifier at point."
  (interactive)
  (let ((i (eclim--java-identifier-at-point t)))
    (eclim/with-results hits ("java_search" "-n" "-f" ("-o" (car i))
                              ("-l" (length (cdr i))) ("-x" "references"))
      (eclim--find-display-results (cdr i) hits))))

(defun eclim-java-find-type (type-name &optional case-insensitive)
  "Search the project for a given class.
The TYPE-NAME is the pattern, which will be used for the search.
If invoked with the universal argument the search will be made
CASE-INSENSITIVE."
  (interactive
   (list (read-string "Name: "
                      (let ((case-fold-search nil)
                            (current-symbol (symbol-name (symbol-at-point))))
                        (if (string-match-p "^[A-Z]" current-symbol)
                            current-symbol
                          (eclim--java-current-type-name))))
         "P"))
  (eclim-java-find-generic "workspace" "declarations" "type"
                           type-name case-insensitive t))

(defun eclim-java-find-generic (scope context type pattern
                                      &optional case-insensitive open-single-file)
  "Search within SCOPE (all/project/type) for a TYPE \
\(all/annotation/class/classOrEnum/classOrInterface/constructor/enum \
/field/interface/method/package/type) matching the given CONTEXT \
\(all/declarations/implementors/references) and PATTERN.
If invoked with the universal argument the search will be made CASE-INSENSITIVE.
OPEN-SINGLE-FILE is passed to `eclim--java-package-components'."
  (interactive (list (eclim--completing-read "Scope: " eclim--java-search-scopes)
                     (eclim--completing-read "Context: " eclim--java-search-contexts)
                     (eclim--completing-read "Type: " eclim--java-search-types)
                     (read-string "Pattern: ")
                     "P"))
  (eclim/with-results hits ("java_search" ("-p" pattern) ("-t" type)
                            ("-x" context) ("-s" scope)
                            (if case-insensitive '("-i" "")))
    (eclim--find-display-results pattern hits open-single-file)))

(defun eclim--java-package-components (package)
  "Return the components of a Java PACKAGE statement."
  (split-string package "\\."))

(defun eclim--java-current-package ()
  "Return the package for the class in the current buffer."
  (save-excursion
    (goto-char 0)
    (if (re-search-forward "package \\(.*?\\);" (point-max) t)
        (match-string-no-properties 1))))

(defun eclim-soft-revert-imports (_ignore-auto _noconfirm)
  "Can be used as a REVERT-BUFFER-FUNCTION to only replace the imports section \
of a java source file.  This will preserve the undo history."
  (interactive)
  (cl-flet ((cut-imports ()
              (goto-char (point-min))
              (if (re-search-forward "^import" nil t)
                  (progn
                    (beginning-of-line)
                    (let ((beg (point)))
                      (goto-char (point-max))
                      (re-search-backward "^import")
                      (end-of-line)
                      (let ((imports (buffer-substring-no-properties beg (point))))
                        (delete-region beg (point))
                        imports)))
                (progn
                  (goto-char (point-min))
                  (if (re-search-forward "^package" nil t)
                      (forward-line 1))
                  (delete-blank-lines)
                  (insert "\n\n\n")
                  (forward-line -2)))))
    (let* ((fname (buffer-file-name))
           (new-imports (with-temp-buffer
                          (insert-file-contents fname)
                          (cut-imports))))
      (save-excursion
        (clear-visited-file-modtime)
        (cut-imports)
        (widen)
        (insert new-imports)
        (set-buffer-modified-p nil)
        (set-visited-file-modtime)))))

(defun eclim-java-import (type)
  "Add an import statement for the given TYPE, if one does not exist already."
  (unless (save-excursion
            (goto-char (point-min))
            (re-search-forward (format "^import %s;" type) nil t))
    (let ((revert-buffer-function 'eclim-soft-revert-imports))
      (eclim/execute-command "java_import" "-p" "-f" "-o" "-e" ("-t" type))
      (eclim--problems-update-maybe)
      (message "Imported %s" type))))

(defun eclim-java-import-organize (&optional types)
  "Check the current file for missing imports, remove unused imports and \
sort import statements.  If TYPES is non-nil, find imports for all listed types."
  (interactive)
  (let ((revert-buffer-function 'eclim-soft-revert-imports))
    (eclim/with-results res
      ("java_import_organize" "-p" "-f" "-o" "-e"
       (when types (list "-t" (cl-reduce (lambda (a b) (concat a "," b)) types))))
      (eclim--problems-update-maybe)
      (when (vectorp res)
        (save-excursion
          (eclim-java-import-organize
           (mapcar (lambda (imports)
                     (eclim--completing-read "Import: " (append imports '())))
                   res)))))))

(defun eclim-java-new (project type name-with-package)
  "Create a new class of TYPE in PROJECT with fully-qualified name \
NAME-WITH-PACKAGE."
  (interactive (list (eclim-project-name)
                     (eclim--completing-read "Type: " eclim--java-new-types)
                     (read-string "Name: " (eclim--java-current-package))))
  (let ((root-dir (eclim--completing-read "Root: " (eclim/java-src-dirs project))))
    (when eclim-print-debug-messages
      (message "eclim-java-new: project: %s, type: %s, file: %s"
               project type name-with-package))
    (eclim/with-results new-file ("java_new"
                                  ("-p" project)
                                  ("-t" type)
                                  ("-n" name-with-package)
                                  ("-r" root-dir))
      (eclim--find-file new-file))))

(defun eclim--signature-has-keyword (sig java-keyword)
  "Return non-nil if a method signature SIG has the keyword JAVA-KEYWORD."
  ;; \_< is beginning of identifier E.g. don't match do_abstract".
  (string-match-p (format "\\_<%s\\_>" java-keyword) sig))

(defun eclim--colorize-signature (sig)
  "Minimal colorization for a method signature (SIG) that we offer for \
completion, so the essential bits stand out from the block of text that
ido presents.  Keep this minimal: more highlighting could easily make things
worse not better."
  (save-match-data
    (mapc #'(lambda (re-g-f)             ;; expecting single match per RE
              (when (string-match (elt re-g-f 0) sig)
                (setq sig (replace-match
                           (propertize (match-string (elt re-g-f 1) sig)
                                       'face (elt re-g-f 2))
                           nil nil sig (elt re-g-f 1)))))
          '(("\\_<\\(class\\|interface\\)\\s +\\([[:alnum:]_]+\\_>\\)"
             2 font-lock-type-face)
            ("\\_<\\([[:alnum:]_]+\\)(" 1 font-lock-function-name-face)
            ("all [[:digit:]]+ \\w+ methods" 0 font-lock-function-name-face))))
  sig)


(defun eclim-java-implement (&optional name)
  "Implement or override methods from parents of the class, prompting the \
user to select with a completing read (even if one, as confirmation).  If
NAME was specified programmatically, filters for that name (strict,
although only on method name not arguments) and if only one choice
implement it without prompting.  The actual change is done by Eclipse
and will be close to point although not necessarily at it (e.g. if in a
sub block)."
  (interactive)
  (eclim/with-results list-response ("java_impl" "-p" "-f" "-o")
    (let* ((supertypes (assoc-default 'superTypes list-response))
           ;; "Choices" are lists of user-friendly method names. We want to
           ;; present interfaces/abstract first, otherwise Object can barge in.
           (choices nil) (choices-opt nil) (choices-last nil)
           ;; Maps a choice to a (supertype method1 method2...), needed
           ;; when we request eclim to implement that method.
           (choice-data (make-hash-table :test 'equal)))
      (cl-loop
         for super-entry across supertypes
         do (let* ((package (assoc-default 'packageName super-entry))
                   (super-sig (assoc-default 'signature super-entry))
                   ;; Erase type arguments. This looks like "class List<String>".
                   (friendly-super (replace-regexp-in-string "<[^<]*>" "" super-sig))
                   (full-super (concat package "."
                                       (replace-regexp-in-string "^\\w+ " ""
                                                                 friendly-super)))
                   (is-interface (eclim--signature-has-keyword
                                  super-sig "interface"))
                   (methods (assoc-default 'methods super-entry))
                   (required-methods nil))   ;; Eclim names here
              (cl-loop
                 for method across methods
                 ;; Skip if specified name doesn't match.
                 if (or (null name)
                        (string-match-p (format "\\_<%s(" (regexp-quote name))
                                        method))
                 do
                 ;; This regexp stuff is how vim (and thus eclim) does it. Nothing
                 ;; fancy. If it breaks, Google eclim/java/impl.vim for changes.
                   (let ((name-for-eclim
                          ;; Remove keywords and return type. \_< begins identifier.
                          (replace-regexp-in-string
                           "^\\s *[^(]*\\(\\_<[[:alnum:]_]+(\\)"
                           "\\1"
                           ;; Remove any and all type parameters.
                           (replace-regexp-in-string "<[^<]*>" "" method)))
                         ;; For the user, we have very different requirements. I
                         ;; like knowing public and abstract, and the return
                         ;; type. I hate packages -- I'm already implementing
                         ;; this class so I know.
                         (friendly-name
                          ;; Packages are non-trivial to find (think Map.Entry)
                          ;; but if we stop at the first capitalized portion
                          ;; we're okay.
                          (replace-regexp-in-string "\\_<[[:lower:]][[:alnum:]_]+\\."
                                                    "" method))
                         (is-required (or is-interface (eclim--signature-has-keyword
                                                        method "abstract"))))
                     (let ((choice (format "%s [%s]" friendly-name friendly-super)))
                       ;; This is probably overkill but what if our package
                       ;; erasing resulted in duplicates? Use full name then. As
                       ;; in, really full.
                       (when (gethash choice choice-data)
                         (setq choice (format "%s [%s]" name-for-eclim full-super)))
                       (cond (is-required (push choice choices))
                             ;; others like it?
                             ((member full-super '("java.lang.Object"))
                              (push choice choices-last))
                             (t (push choice choices-opt)))
                       (puthash choice (list full-super name-for-eclim) choice-data)
                       (when is-required (push name-for-eclim required-methods)))))
              ;; Since we don't allow multiple selection like Eclipse / vim,
              ;; let's provide for the cases that matter. Note that full
              ;; non-abstract overrides are typically a use case for
              ;; *delegates*.
              (when (> (length required-methods) 1) ;; 1 method already there
                (let ((choice
                       (format "<all %d %s methods from %s>"
                               (length required-methods)
                               (cond (is-interface "missing") (name) (t "abstract"))
                               friendly-super))
                      (data (cons full-super (reverse required-methods))))
                  (push choice choices) ;; I'll not worry about conflict here.
                  (puthash choice data choice-data)))))
      ;; Keep inital order, except for our tweaks.
      (setq choices (append (nreverse choices) (reverse choices-opt)
                            (reverse choices-last)))
      (unless choices
        (if name (error "No such unimplemented method: %s" name) ;most likely
          (error "No candidates to implement"))) ;; Rare, given Object ancestor.

      ;; Ask user even if only one choice, for confirmation. Otherwise it's
      ;; possible to not even notice the change from a bad key combo. Unless
      ;; we were called programmatically a for specific method.
      (let ((choice
             (if (and name (eq 1 (length choices)))
                 (cl-first choices)
               (funcall eclim-interactive-completion-function
                        "Implement: "
                        (mapcar #'eclim--colorize-signature choices)
                        nil t))))    ; require match
        (setq choice (substring-no-properties choice)) ; uncolorize
        (let* ((eclim-data (gethash choice choice-data))
               (super (car eclim-data)) (methods (cdr eclim-data))
               (methods-str (json-encode methods)))
          (eclim/with-results impl-result ("java_impl" "-p" "-f" "-o"
                                           ("-s" super) ("-m" methods-str))
            ;; eclim should give us a smaller list if it did something. But
            ;; it's probably not worth an error in case this changes.
            (revert-buffer t t t)))))))

(defun eclim-package-and-class ()
  (let ((package-name (eclim--java-current-package))
        (class-name   (eclim--java-current-class-name)))
    (if package-name (concat package-name "." class-name)
      class-name)))

(defun eclim-run-class (&optional editp)
  "Run the current class.
If optional EDITP is non-nil, edit the command before running
it.  The following format specs are substituted in the eclim command:

   %p project name
   %c fully qualified class name
   %r root directory of the current project

See help string of 'eclim ? java` for available
arguments.  Currently available arguments:

    java -p project [-d] [-c classname] [-w workingdir]
         [-v vmargs] [-s sysprops] [-e envargs] [-a args]"
  (interactive "P")
  (if (not (string= major-mode "java-mode"))
      (message "Sorry cannot run current buffer.")
    (let* ((class (eclim-package-and-class))
           (hist-command (and eclim--run-class-commands
                              (assoc class eclim--run-class-commands)))
           (command (or (cdr hist-command)
                        (concat eclim-executable " -command java -p %p -c %c"))))
      (when editp
        (setq command
              (read-string "Run command: " command 'eclim--run-class-history))
        (if hist-command
            (setf (cdr hist-command) command)
          (add-to-list 'eclim--run-class-commands (cons class command))))
      (compile (format-spec command `((?p . ,(eclim-project-name))
                                      (?c . ,class)
                                      (?r . ,(eclim--project-dir))))))))

(defun eclim--java-junit-file (project file offset encoding)
  (concat eclim-executable
          " -command java_junit -p " project
          " -f " file
          " -o " (number-to-string offset)
          " -e " encoding))

(defun eclim--java-junit-project (project encoding)
  (concat eclim-executable
          " -command java_junit -p " project
          " -e " encoding))

(defun eclim--buffer-contains-substring (string)
  (save-excursion
    (save-match-data
      (goto-char (point-min))
      (search-forward string nil t))))

(defun eclim--java-make-popup-item (correction)
  (popup-make-item
   (cdr (assoc 'description correction))
   :value (cdr (assoc 'index correction))
   :document (cdr (assoc 'preview correction))))

(defun eclim-java-junit-buffer? ()
  (eclim--buffer-contains-substring "org.junit.Test"))

(defun eclim-java-testng-buffer? ()
  (eclim--buffer-contains-substring "org.testng.annotations.Test"))

(defun eclim-run-junit (project file offset encoding)
  "Run the current JUnit tests for current PROJECT or \
current class or current method in FILE at OFFSET with ENCODING.

This method hooks onto the running Eclipse process and is thus
much faster than running mvn test -Dtest=TestClass#method."
  (interactive (list (eclim-project-name)
                     (eclim--project-current-file)
                     (eclim--byte-offset)
                     (eclim--current-encoding)))
  (if (not (string= major-mode "java-mode"))
      (message "Running JUnit tests only makes sense for Java buffers.")
    (compile (if (eclim-java-junit-buffer?)
                 (eclim--java-junit-file project file offset encoding)
               (eclim--java-junit-project project encoding)))))

(defun eclim-java-browse-documentation-at-point (&optional arg)
  "Browse the documentation of the element at point.
With the prefix ARG, ask for pattern.  Pattern is a shell glob
pattern, not a regexp.  Rely on `browse-url' to open user defined
browser."
  (interactive "P")
  (let ((symbol (if arg
                    (read-string "Glob Pattern: ")
                  (symbol-at-point)))
        (proj-name (or (eclim-project-name)
                       (error "Not in Eclim project"))))
    (if symbol
        (let* ((urls (if arg
                         (eclim/execute-command "java_docsearch"
                                                ("-n" proj-name)
                                                "-f"
                                                ("-p" symbol))
                       (let ((bounds (bounds-of-thing-at-point 'symbol)))
                         (eclim/execute-command "java_docsearch"
                                                ("-n" proj-name)
                                                "-f"
                                                ("-l" (- (cdr bounds) (car bounds)))
                                                ("-o" (save-excursion
                                                        (goto-char (car bounds))
                                                        (eclim--byte-offset)))))))
               ;; convert from vector to list
               (urls (append urls nil)))
          (if urls
              (let ((url (if (> (length urls) 1)
                             (eclim--completing-read "Browse: " (append urls nil))
                           (car urls))))
                (browse-url url))
            (message "No documentation for '%s' found" symbol)))
      (message "No element at point"))))

(defun eclim-java-show-documentation-for-current-element ()
  "Displays the doc comments for the element at the pointers position."
  (interactive)
  (let ((symbol (symbol-at-point)))
    (if symbol
        (let ((bounds (bounds-of-thing-at-point 'symbol)))
          (eclim/with-results doc ("java_element_doc"
                                   ("-p" (eclim-project-name))
                                   "-f"
                                   ("-l" (- (cdr bounds) (car bounds)))
                                   ("-o" (save-excursion
                                           (goto-char (car bounds))
                                           (eclim--byte-offset))))

            (pop-to-buffer "*java doc*")
            (use-local-map eclim-java-show-documentation-map)

            (eclim--java-show-documentation-and-format doc)
            ;; return the docstring
            (prog1 (buffer-string)
              (message (substitute-command-keys
                        (concat
                         "\\[forward-button] - move to next link, "
                         "\\[backward-button] - move to previous link, "
                         "\\[eclim-quit-window] - quit"))))))

      (message "No element found at point."))))

(defun eclim--java-show-documentation-and-format (doc &optional add-to-history)
  (make-local-variable 'eclim-java-show-documentation-history)
  (setq eclim-java-show-documentation-history
        (if add-to-history
            (push (buffer-substring (point-min) (point-max))
                  eclim-java-show-documentation-history)))

  (erase-buffer)
  (insert (cdr (assoc 'text doc)))

  (let ((links (cdr (assoc 'links doc)))
        link placeholder text href)
    (dotimes (i (length links))
      (setq link (aref links i))
      (setq text (replace-regexp-in-string "</?code>" "" (cdr (assoc 'text link))))
      (setq href (cdr (assoc 'href link)))
      (setq placeholder (format "|%s[%s]|" text i))
      (goto-char (point-min))
      (while (search-forward placeholder nil t)
        (replace-match text)
        (make-text-button (match-beginning 0)
                          (+ (match-beginning 0) (length text))
                          'follow-link t
                          'action 'eclim-java-show-documentation-follow-link
                          'url href))))

  (when add-to-history
    (goto-char (point-max))
    (insert "\n\n")
    (insert-text-button "back" 'follow-link t 'action
                        'eclim--java-show-documentation-go-back))
  (goto-char (point-min)))

(defun eclim-java-show-documentation-follow-link (link)
  "Follow the LINK at point while browsing javadocs."
  (interactive)
  (let ((url (button-get link 'url)))
    (if (string-match "^eclipse-javadoc" url)
        (eclim/with-results doc ("java_element_doc"
                                 ("-u" url))
          (eclim--java-show-documentation-and-format doc t))

      (if (string-match "^\.\." url)
          (let* ((doc-root-vars '(eclim-java-documentation-root
                                  eclim-java-android-documentation-root))
                 (path (replace-regexp-in-string "^[./]+" "" url))
                 (fullpath (cl-some (lambda (var)
                                      (let ((fullpath (concat (symbol-value var)
                                                              "/"
                                                              path)))
                                        (if (file-exists-p (replace-regexp-in-string
                                                            "#.+"
                                                            ""
                                                            fullpath))
                                         fullpath)))
                                    doc-root-vars)))
            (if fullpath
                (browse-url (concat "file://" fullpath))

              (message (concat "Can't find the root directory for this file: %s. "
                               "Are the applicable variables set properly? (%s)")
                       path
                       (mapconcat (lambda (var)
                                    (symbol-name var))
                                  doc-root-vars ", "))))

        (message "There is no handler for this kind of url yet. Implement it! : %s"
                 url)))))

(defun eclim--java-show-documentation-go-back (_link)
  (erase-buffer)
  (insert (pop eclim-java-show-documentation-history))
  (goto-char (point-min)))

(provide 'eclim-java)
;;; eclim-java.el ends here
