(define-package "evil-dvorak" "20160416.1841" "evil keybindings for that work with dvorak mode"
  '((evil "1.0.8"))
  :commit "824f7c56980d72a0ff04c662223540cd66f13754" :authors
  '(("Joshua Branson"))
  :maintainer
  '("Joshua Branson")
  :keywords
  '("dvorak" "evil" "vim"))
;; Local Variables:
;; no-byte-compile: t
;; End:
