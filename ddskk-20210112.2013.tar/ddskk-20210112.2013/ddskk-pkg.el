(define-package "ddskk" "20210112.2013" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "a266f70eb99ffb657b7821c2e1de49f5184a59ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
