(define-package "elhome" "20161025.2042" "A framework for a \"home\" Emacs configuration"
  '((initsplit "20120630"))
  :commit "e789e806469af3e9705f72298683c21f6c3a516d" :authors
  '(("Dave Abrahams" . "dave@boostpro.com"))
  :maintainer
  '("Demyan Rogozhin" . "demyan.rogozhin@gmail.com")
  :keywords
  '("lisp")
  :url "http://github.com/demyanrogozhin/elhome")
;; Local Variables:
;; no-byte-compile: t
;; End:
