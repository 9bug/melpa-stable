(define-package "el-x" "20140111.2201" "Emacs-lisp extensions."
  '((cl-lib "0.2"))
  :commit "e7c333d4fc31a90f4dca951efe21129164b42605" :authors
  '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainer
  '("Yann Hodique" . "yann.hodique@gmail.com")
  :keywords
  '("lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
