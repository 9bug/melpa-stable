(define-package "assess" "20200211.1817" "Test support functions"
  '((emacs "24.4")
    (m-buffer "0.15"))
  :commit "5bac045b273623772b6a2d820997d50f7ab4e466" :authors
  '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@russet.org.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
