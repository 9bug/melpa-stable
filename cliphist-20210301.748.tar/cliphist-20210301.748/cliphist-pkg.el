(define-package "cliphist" "20210301.748" "Read data from clipboard managers at Linux and Mac"
  '((emacs "24.3")
    (ivy "0.9.0"))
  :commit "1ef50459fa6044c4d571cec0009368948bcf5fc5" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
