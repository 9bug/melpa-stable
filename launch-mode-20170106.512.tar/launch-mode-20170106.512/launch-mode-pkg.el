(define-package "launch-mode" "20170106.512" "Major mode for launch-formatted text"
  '((emacs "24.4"))
  :commit "25ebd4ba77afcbe729901eb74923dbe9ae81c313" :authors
  '(("iory" . "ab.ioryz@gmail.com"))
  :maintainer
  '("iory" . "ab.ioryz@gmail.com")
  :url "https://github.com/iory/launch-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
