(define-package "spdx" "20210306.1600" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "b9f49bab9551e8ca1232582acffdd0a90aaa35f3" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
