(define-package "ado-mode" "20210219.1548" "Major mode for editing Stata-related files"
  '((emacs "24.1"))
  :commit "438e2b9ca1ce9fd1043998359dfe5a32a0ddb6d0" :authors
  '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainer
  '("Bill Rising" . "brising@alum.mit.edu")
  :keywords
  '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :url "https://github.com/louabill/ado-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
