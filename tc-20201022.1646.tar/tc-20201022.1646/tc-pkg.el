(define-package "tc" "20201022.1646" "a Japanese input method with T-Code on Emacs" 'nil :commit "5c6bbb0ff08e5d81e905198156ae5600df7ff7ab" :authors
  '(("Kaoru Maeda" . "maeda@src.ricoh.co.jp")
    ("Yasushi Saito" . "yasushi@cs.washington.edu")
    ("KITAJIMA Akira" . "kitajima@isc.osakac.ac.jp"))
  :maintainer
  '("KITAJIMA Akira"))
;; Local Variables:
;; no-byte-compile: t
;; End:
