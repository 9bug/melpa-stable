(define-package "emacsc" "20210302.806" "helper for emacsc(1)" 'nil :commit "409fc548bb650c6e832b459c756b13de68147117" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
