(define-package "wandbox" "20170603.1231" "Wandbox client"
  '((emacs "24")
    (request "0.3.0")
    (s "1.10.0"))
  :commit "e002fe41f2cd9b4ce2b1dc80b83301176e9117f1" :authors
  '(("KOBAYASHI Shigeru (kosh)" . "shigeru.kb@gmail.com"))
  :maintainer
  '("KOBAYASHI Shigeru (kosh)" . "shigeru.kb@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kosh04/emacs-wandbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
