(define-package "magik-mode" "20200304.1323" "mode for editing Magik + some utils." 'nil :commit "e54f934952cde3f96d6a131968295d993b3cf624" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
