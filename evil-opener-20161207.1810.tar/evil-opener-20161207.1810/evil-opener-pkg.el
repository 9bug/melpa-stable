(define-package "evil-opener" "20161207.1810" "opening urls as buffers in evil"
  '((evil "1.2.12")
    (opener "0.2.2"))
  :commit "c384f67278046fdcd220275fdd212ab85672cbeb" :authors
  '(("Tim Reddehase" . "tr@rightsrestricted.com"))
  :maintainer
  '("Tim Reddehase" . "tr@rightsrestricted.com")
  :keywords
  '("url" "http" "files")
  :url "https://github.com/0robustus1/opener.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
