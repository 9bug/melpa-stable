# Should match setup.py --version
__version__ = "0.0.10"
