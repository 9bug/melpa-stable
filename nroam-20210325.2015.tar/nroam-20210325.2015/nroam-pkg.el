(define-package "nroam" "20210325.2015" "Org-roam backlinks within org-mode buffers"
  '((emacs "26.1")
    (org-roam "1.2.3")
    (org "9.4.4"))
  :commit "a5508d9958c2148c04ec32d7b3a9f72423e4b0aa" :authors
  '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainer
  '("Nicolas Petton" . "nicolas@petton.fr")
  :keywords
  '("outlines" "convenience")
  :url "https://github.com/NicolasPetton/nroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
