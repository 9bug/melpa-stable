(define-package "magnatune" "20151030.1935" "browse magnatune's music catalog"
  '((dash "2.9.0")
    (s "1.9.0"))
  :commit "605b01505ba30589c77ebb4c96834b5072ccbdd4")
;; Local Variables:
;; no-byte-compile: t
;; End:
