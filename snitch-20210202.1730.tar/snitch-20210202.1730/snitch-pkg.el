(define-package "snitch" "20210202.1730" "An Emacs firewall"
  '((emacs "27.1"))
  :commit "3b3e7f1bf612c4624764d1ec4b1a96e4d2850b05" :authors
  '(("Trevor Bentley" . "snitch.el@x.mrmekon.com"))
  :maintainer
  '("Trevor Bentley" . "snitch.el@x.mrmekon.com")
  :keywords
  '("processes" "comm")
  :url "https://github.com/mrmekon/snitch-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
