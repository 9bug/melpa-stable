(define-package "lpy" "20201027.1425" "A lispy interface to Python"
  '((emacs "25.1")
    (lispy "0.27.0"))
  :commit "076ce9acb68f6ac1b39127b634a91ffd865d13d8" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("python" "lisp")
  :url "https://github.com/abo-abo/lpy")
;; Local Variables:
;; no-byte-compile: t
;; End:
