(define-package "geiser-chicken" "20210328.418" "Chicken's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "555b25ba3b3e4fd5a78687970342ba76c8935020" :authors
  '(("Daniel Leslie"))
  :maintainer
  '("Daniel Leslie")
  :keywords
  '("languages" "chicken" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chicken")
;; Local Variables:
;; no-byte-compile: t
;; End:
