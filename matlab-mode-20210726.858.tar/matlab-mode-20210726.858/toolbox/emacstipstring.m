function emacstipstring(expr)
% Take EXPR, and convert into a tooltip friendly string.
% This utility is mean to be used by emacs to create text to display
% whie debugging code.
    
    disp(expr)
end

