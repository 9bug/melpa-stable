(define-package "autocrypt" "20201115.912" "Autocrypt implementation"
  '((emacs "25.1"))
  :commit "926b88e3719ac59e6539b4d3cae9d0f5159c9114" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
