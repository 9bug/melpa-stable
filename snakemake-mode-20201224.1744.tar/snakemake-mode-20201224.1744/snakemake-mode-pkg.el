(define-package "snakemake-mode" "20201224.1744" "Major mode for editing Snakemake files"
  '((emacs "24.5")
    (cl-lib "0.5")
    (magit-popup "2.4.0"))
  :commit "592901893f297099ffb759b4d1359bcd3411d1a9" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
