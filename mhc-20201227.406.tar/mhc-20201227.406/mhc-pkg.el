(define-package "mhc" "20201227.406" "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :commit "1cd9cbc7f8cfe40833d1af726644ae45a3d07dc0" :authors
  '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainer
  '("Yoshinari Nomura" . "nom@quickhack.net")
  :keywords
  '("calendar")
  :url "http://www.quickhack.net/mhc")
;; Local Variables:
;; no-byte-compile: t
;; End:
