(define-package "modus-themes" "20210404.1301" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "466a335ce68acf2a3d910a1f9d31fb7ab749b0f2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
