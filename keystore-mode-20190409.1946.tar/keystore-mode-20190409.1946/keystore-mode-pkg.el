(define-package "keystore-mode" "20190409.1946" "A major mode for viewing and managing (java) keystores"
  '((emacs "24.3")
    (origami "1.0")
    (s "1.12.0")
    (seq "2.20"))
  :commit "43bd5926348298d077c7221f37902c990df3f951" :authors
  '(("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com"))
  :maintainer
  '("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/peterpaul/keystore-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
