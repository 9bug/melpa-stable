(define-package "embark" "20210328.1709" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "33e9af8403b22f75c01db96f39aee344de6ffaa8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
