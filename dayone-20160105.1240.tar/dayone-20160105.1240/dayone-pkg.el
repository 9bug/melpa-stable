(define-package "dayone" "20160105.1240" "Utility script for Day One"
  '((uuid "0.0.3")
    (mustache "0.22")
    (ht "1.5"))
  :commit "ab628274f0806451f23bce16f62a6a11cbf91a2b" :authors
  '(("mori-dev" . "mori.dev.asdf@gmail.com"))
  :maintainer
  '("mori-dev" . "mori.dev.asdf@gmail.com")
  :keywords
  '("day one" "tools" "convenience")
  :url "https://github.com/mori-dev/emacs-dayone")
;; Local Variables:
;; no-byte-compile: t
;; End:
