(define-package "xmlunicode" "20200823.755" "Unicode support for XML" 'nil :commit "0c2ee59888042d516f79a7b96526cbeae611c9bc" :authors
  '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainer
  '("Norman Walsh" . "ndw@nwalsh.com")
  :keywords
  '("utf-8" "unicode" "xml" "characters"))
;; Local Variables:
;; no-byte-compile: t
;; End:
