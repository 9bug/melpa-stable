(define-package "haskell-emacs-base" "20150714.1559" "Haskell functions from Prelude"
  '((haskell-emacs "2.4.0"))
  :commit "a2c6a079175904689eed7c6c200754bfa85d1ed9" :authors
  '(("Florian Knupfer"))
  :maintainer
  '("Florian Knupfer")
  :keywords
  '("haskell" "emacs" "ffi")
  :url "https://github.com/knupfer/haskell-emacs/modules/base")
;; Local Variables:
;; no-byte-compile: t
;; End:
