(define-package "xml-quotes" "20200301.1222" "read quotations from an XML document" 'nil :commit "8fc21e43b45f9a50b24642412f05afcc3a316a1f" :authors
  '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainer
  '("Norman Walsh" . "ndw@nwalsh.com")
  :keywords
  '("xml" "quotations")
  :url "https://github.com/ndw/xml-quotes")
;; Local Variables:
;; no-byte-compile: t
;; End:
