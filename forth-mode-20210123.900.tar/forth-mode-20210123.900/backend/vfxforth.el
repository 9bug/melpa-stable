(provide 'vfxforth)
