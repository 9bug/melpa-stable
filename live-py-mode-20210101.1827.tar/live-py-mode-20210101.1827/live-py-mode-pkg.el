(define-package "live-py-mode" "20210101.1827" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "5e1b94f98d1d01da00c63b8f7950fbc85a0a0897" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
