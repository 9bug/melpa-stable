(define-package "js-codemod" "20190921.941" "Run js-codemod on current sentence or selected region"
  '((emacs "24.4"))
  :commit "056bdf3e5e0c807b8cf17edb5834179a90fb722b" :authors
  '((nil . "Torgeir Thoresen <@torgeir>"))
  :maintainer
  '(nil . "Torgeir Thoresen <@torgeir>")
  :keywords
  '("js" "codemod" "region"))
;; Local Variables:
;; no-byte-compile: t
;; End:
