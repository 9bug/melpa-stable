({{head}} "^{{body}}$"
  (lambda ({{args}})

    ))
