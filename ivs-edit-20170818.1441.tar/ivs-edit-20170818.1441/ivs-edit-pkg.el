(define-package "ivs-edit" "20170818.1441" "IVS (Ideographic Variation Sequence) editing tool"
  '((emacs "24.3")
    (dash "2.6.0")
    (cl-lib "1.0"))
  :commit "5db39c234aa7393b591168a4fd0a9a4cbbca347d" :authors
  '(("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>"))
  :maintainer
  '("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>")
  :keywords
  '("text")
  :url "http://github.com/kawabata/ivs-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
