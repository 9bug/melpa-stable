(define-package "capture" "20130828.1644" "screencasting with \"avconv\" or \"ffmpeg\"" 'nil :commit "1bb26060311da76767f70096218313fc93b0c806" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
