(define-package "nndiscourse" "20210219.1949" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "20210210")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "20200417"))
  :commit "c6074af3b60ef7af7d9c45b8ad1daa21296a5e04" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
