(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "937426d38b6459e62db9eb66e4c1d35db585082a")
;; Local Variables:
;; no-byte-compile: t
;; End:
