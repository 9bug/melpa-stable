(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7e68913b79173dea0aae00ad7d5e74c9ba509a89")
;; Local Variables:
;; no-byte-compile: t
;; End:
