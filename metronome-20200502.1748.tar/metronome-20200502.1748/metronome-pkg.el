(define-package "metronome" "20200502.1748" "A simple metronome"
  '((emacs "25.1"))
  :commit "18257ecdd7b3d816104e83a5f0f96e676cc9fbfc" :authors
  '(("Jonathan Gregory <jgrg at autistici dot org>"))
  :maintainer
  '("Jonathan Gregory <jgrg at autistici dot org>")
  :url "https://gitlab.com/jagrg/metronome")
;; Local Variables:
;; no-byte-compile: t
;; End:
