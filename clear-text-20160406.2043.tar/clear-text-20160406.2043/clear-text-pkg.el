(define-package "clear-text" "20160406.2043" "Make you use clear text" 'nil :commit "b50669b6077d6948f72cb3c649281d206e0c2f2b" :authors
  '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainer
  '("Chunyang Xu" . "xuchunyang56@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/xuchunyang/clear-text.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
