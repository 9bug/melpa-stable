(define-package "standoff-mode" "20171115.1731" "Create stand-off markup, also called external markup." 'nil :commit "76cc8122a39a3ef5947d706377b007ef53a354fe" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
