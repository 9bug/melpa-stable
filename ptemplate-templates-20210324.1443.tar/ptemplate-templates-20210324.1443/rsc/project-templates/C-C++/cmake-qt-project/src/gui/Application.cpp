#include "Application.hpp"

Application::Application(int &argc, char **argv) : QApplication(argc, argv) {}
