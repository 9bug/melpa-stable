(define-package "notmuch" "20210205.1412" "run notmuch within emacs" 'nil :commit "4e209ca99ac8084a357c6fc8d7773f6207cfa16d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
